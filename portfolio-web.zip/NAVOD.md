# Jak dát portfolio na web

## 1. Nahrání na Netlify (zdarma, cca 5 minut)
1. Rozbal `portfolio-web.zip`. Vznikne složka `web` s `index.html`, `og-image.jpg`, `favicon.svg` a složkou `assets`.
2. Jdi na https://app.netlify.com/drop a přihlas se (třeba přes Google).
3. Přetáhni celou složku `web` do okna prohlížeče.
4. Za chvilku dostaneš odkaz typu `nahodne-jmeno.netlify.app`. Web už běží.
5. V **Site configuration → Change site name** si adresu přejmenuj, třeba na `annabrabcova.netlify.app`.

Až budeš chtít něco změnit, v sekci **Deploys** přetáhneš novou verzi složky znovu.

## 2. Vlastní doména
1. Kup doménu, např. `annabrabcova.cz` (Wedos, Forpsi, Active24, cca 150–300 Kč ročně).
2. V Netlify otevři **Domain management → Add a domain** a zadej ji.
3. Netlify ti ukáže, jaké DNS záznamy nastavit u registrátora (obvykle záznam A pro hlavní doménu a CNAME pro `www`). Zkopíruj je přesně tak, jak je Netlify zobrazí.
4. Za pár hodin doména začne fungovat a Netlify samo zapne HTTPS.

## 3. Náhled při sdílení (LinkedIn, mail)
V `index.html` je náhledový obrázek nastavený na `https://annabrabcova.cz/og-image.jpg`.
Pokud budeš mít jinou doménu, přepiš v `index.html` adresu `annabrabcova.cz` (2× nahoře v hlavičce) na svoji.
Náhled pak otestuješ na https://www.linkedin.com/post-inspector/
